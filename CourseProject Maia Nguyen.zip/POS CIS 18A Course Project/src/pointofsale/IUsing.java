package pointofsale;

public interface IUsing {
	public void showInfo();
	public int input();
}
